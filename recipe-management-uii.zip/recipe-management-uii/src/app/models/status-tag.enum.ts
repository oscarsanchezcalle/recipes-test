export enum StatusTag {
  None = 'None',
  Favorite = 'Favorite',
  ToTry = 'ToTry',
  MadeBefore = 'MadeBefore'
}
