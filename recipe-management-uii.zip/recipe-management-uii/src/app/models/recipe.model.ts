import { StatusTag } from './status-tag.enum';

export interface Recipe {
  id: number;
  name: string;
  ingredients: string;
  instructions: string;
  cuisineType: string;
  preparationTime: string; // Corresponds to string on backend
  difficulty: string;      // Corresponds to string on backend
  numberOfServings: number;
  status: StatusTag;
}
