import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { CommonModule } from '@angular/common';

import { State as RecipesState } from '../../store/reducers/recipe.reducer';
import { Recipe } from '../../models/recipe.model';
import { StatusTag } from 'app/models/status-tag.enum';
import * as RecipeActions from '../../store/actions/recipe.actions';
import { selectAllRecipes } from '../../store/selectors/recipe.selectors';

@Component({
  selector: 'app-recipe-form',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './recipe-form.component.html',
  styleUrls: ['./recipe-form.component.scss']
})
export class RecipeFormComponent implements OnInit, OnDestroy {
  recipeForm!: FormGroup;
  isEditMode = false;
  currentRecipeId: number | null = null;
  statusTags = Object.values(StatusTag);
  private subscription = new Subscription();

  constructor(
    private fb: FormBuilder,
    private store: Store<RecipesState>,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.checkEditMode();
  }

  private initForm(): void {
    this.recipeForm = this.fb.group({
      id: [null],
      name: ['', Validators.required],
      ingredients: ['', Validators.required],
      instructions: ['', Validators.required],
      cuisineType: ['', Validators.required],
      preparationTime: ['', Validators.required],
      difficulty: ['', [Validators.required, Validators.pattern('^[1-5]$')]],
      numberOfServings: [1, [Validators.required, Validators.min(1)]],
      status: [StatusTag.None, Validators.required]
    });
  }

  private checkEditMode(): void {
    this.subscription.add(
      this.route.paramMap.subscribe(params => {
        const id = params.get('id');
        if (id) {
          this.isEditMode = true;
          this.currentRecipeId = +id;
          // Dispatch action to ensure recipes are loaded
          this.store.dispatch(RecipeActions.loadRecipes());

          // Select all recipes and find the current one by ID
          this.subscription.add(
            this.store.select(selectAllRecipes).subscribe(recipes => {
              const currentRecipe = recipes.find(r => r.id === this.currentRecipeId);
              if (currentRecipe) {
                this.recipeForm.patchValue(currentRecipe);
              }
            })
          );
        }
      })
    );
  }

  onSubmit(): void {
    if (this.recipeForm.invalid) {
      return;
    }

    const recipe: Recipe = this.recipeForm.value;

    if (this.isEditMode) {
      this.store.dispatch(RecipeActions.updateRecipe({ recipe }));
    } else {
    
      const recipe =  {
        
          name: this.recipeForm.get('name')?.value ?? "",
          ingredients: this.recipeForm.get('ingredients')?.value ?? "",
          instructions: this.recipeForm.get('instructions')?.value ?? "",
          cuisineType: this.recipeForm.get('cuisineType')?.value ?? "",
          preparationTime: this.recipeForm.get('preparationTime')?.value.toString() ?? "",
          difficulty: this.recipeForm.get('difficulty')?.value.toString() ?? "",
          numberOfServings: this.recipeForm.get('numberOfServings')?.value ?? 0,
          status: this.recipeForm.get('status')?.value ?? "",
        
      }
      this.store.dispatch(RecipeActions.addRecipe( {recipe} ));
    }

    this.router.navigate(['/']);
  }

  onCancel(): void {
    this.router.navigate(['/']);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
