import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Recipe } from '../../models/recipe.model';
import { loadRecipes, deleteRecipe } from '../../store/actions/recipe.actions';
import { selectAllRecipes, selectRecipesLoading, selectRecipesError } from '../../store/selectors/recipe.selectors';

import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.scss'],
  standalone: true,
  imports: [CommonModule, RouterModule]
})
export class RecipeListComponent implements OnInit {
  recipes$: Observable<Recipe[]>;
  loading$: Observable<boolean>;
  error$: Observable<any>;

  constructor(private store: Store) {
    this.recipes$ = this.store.select(selectAllRecipes);
    this.loading$ = this.store.select(selectRecipesLoading);
    this.error$ = this.store.select(selectRecipesError);
  }

  ngOnInit(): void {
    this.store.dispatch(loadRecipes());
  }

  deleteRecipe(id: number): void {
    if (confirm('Are you sure you want to delete this recipe?')) {
      this.store.dispatch(deleteRecipe({ id }));
    }
  }
}
