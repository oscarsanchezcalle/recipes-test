import { Component } from '@angular/core';

@Component({
  selector: 'app-recipe-search',
  imports: [],
  templateUrl: './recipe-search.component.html',
  styleUrl: './recipe-search.component.scss'
})
export class RecipeSearchComponent {

}
