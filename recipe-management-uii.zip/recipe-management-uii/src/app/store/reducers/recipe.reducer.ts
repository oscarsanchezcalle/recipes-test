import { createReducer, on } from '@ngrx/store';
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { Recipe } from '../../models/recipe.model';
import * as RecipeActions from '../actions/recipe.actions';

export interface State extends EntityState<Recipe> {
  loading: boolean;
  error: any;
}

export const adapter: EntityAdapter<Recipe> = createEntityAdapter<Recipe>();

export const initialState: State = adapter.getInitialState({
  loading: false,
  error: null,
});

export const recipeReducer = createReducer(
  initialState,
  on(RecipeActions.loadRecipes, state => ({ ...state, loading: true })),
  on(RecipeActions.loadRecipesSuccess, (state, { recipes }) => adapter.setAll(recipes, { ...state, loading: false })),
  on(RecipeActions.loadRecipesFailure, (state, { error }) => ({ ...state, loading: false, error })),

  on(RecipeActions.addRecipe, state => ({ ...state, loading: true })),
  on(RecipeActions.addRecipeSuccess, (state, { recipe }) => adapter.addOne(recipe, { ...state, loading: false })),
  on(RecipeActions.addRecipeFailure, (state, { error }) => ({ ...state, loading: false, error })),

  on(RecipeActions.updateRecipe, state => ({ ...state, loading: true })),
  on(RecipeActions.updateRecipeSuccess, (state, { recipe }) => adapter.updateOne({ id: recipe.id, changes: recipe }, { ...state, loading: false })),
  on(RecipeActions.updateRecipeFailure, (state, { error }) => ({ ...state, loading: false, error })),

  on(RecipeActions.deleteRecipe, state => ({ ...state, loading: true })),
  on(RecipeActions.deleteRecipeSuccess, (state, { id }) => adapter.removeOne(id, { ...state, loading: false })),
  on(RecipeActions.deleteRecipeFailure, (state, { error }) => ({ ...state, loading: false, error }))
);
