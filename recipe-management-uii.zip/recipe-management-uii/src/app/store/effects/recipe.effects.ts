import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { RecipeService } from '../../services/recipe.service';
import * as RecipeActions from '../actions/recipe.actions';

@Injectable()
export class RecipeEffects {
  loadRecipes$ = createEffect(() =>
    this.actions$.pipe(
      ofType(RecipeActions.loadRecipes),
      mergeMap(() =>
        this.recipeService.getRecipes().pipe(
          map(recipes => RecipeActions.loadRecipesSuccess({ recipes })),
          catchError(error => of(RecipeActions.loadRecipesFailure({ error })))
        )
      )
    )
  );

  addRecipe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(RecipeActions.addRecipe),
      mergeMap(({ recipe }) =>
        this.recipeService.addRecipe(recipe).pipe(
          map(newRecipe => RecipeActions.addRecipeSuccess({ recipe: newRecipe })),
          catchError(error => of(RecipeActions.addRecipeFailure({ error })))
        )
      )
    )
  );

  updateRecipe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(RecipeActions.updateRecipe),
      mergeMap(({ recipe }) =>
        this.recipeService.updateRecipe(recipe).pipe(
          map(() => RecipeActions.updateRecipeSuccess({ recipe })),
          catchError(error => of(RecipeActions.updateRecipeFailure({ error })))
        )
      )
    )
  );

  deleteRecipe$ = createEffect(() =>
    this.actions$.pipe(
      ofType(RecipeActions.deleteRecipe),
      mergeMap(({ id }) =>
        this.recipeService.deleteRecipe(id).pipe(
          map(() => RecipeActions.deleteRecipeSuccess({ id })),
          catchError(error => of(RecipeActions.deleteRecipeFailure({ error })))
        )
      )
    )
  );

  constructor(private actions$: Actions, private recipeService: RecipeService) {}
}
