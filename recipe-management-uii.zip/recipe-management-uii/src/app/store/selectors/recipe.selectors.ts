import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State, adapter } from '../reducers/recipe.reducer';

export const selectRecipeState = createFeatureSelector<State>('recipes');

export const { selectAll: selectAllRecipes } = adapter.getSelectors(selectRecipeState);

export const selectRecipesLoading = createSelector(
  selectRecipeState,
  (state: State) => state.loading
);

export const selectRecipesError = createSelector(
  selectRecipeState,
  (state: State) => state.error
);
